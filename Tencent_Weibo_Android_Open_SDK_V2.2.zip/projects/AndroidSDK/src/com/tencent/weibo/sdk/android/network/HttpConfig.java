package com.tencent.weibo.sdk.android.network;

public class HttpConfig {  
		public static final String CRM_SERVER_NAME = "192.168.1.100";
		public static final int CRM_SERVER_PORT = 8088; 
}
